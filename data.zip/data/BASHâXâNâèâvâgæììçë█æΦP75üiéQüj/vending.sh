#!/bin/bash

#金額の定義
price=(180 170 150 140)

#自動販売機のメニュー＆販売プログラム関数
function order_drink(){
menu_drink=$(cat << EOS
---------------------------------------
| Drink Menu                         |
| 1. トキ・コーラ          180円      |
| 2. イル・コーラ          170円      |
| 3. マンタ・グレープ      150円      |
| 4. MRペッパー            140円      |
---------------------------------------

EOS
)

money_pt="Input Money(100,500,1000)==> "
select_drink_pt="Select Drink==> "
change_pt="Changes == "
menu_console="Menu(終了:e ドリンク継続して買う:p)===>"

echo "$menu_drink"
echo -n  $money_pt

for(( ;; ))
do
  read input_money
  if [ $input_money == "100" ] || [ $input_money == "500" ] || [ $input_money == "1000" ]; then
      echo -n $select_drink_pt
      read select_drink
      #echo $input_money
      #echo $select_drink
      changes=$(( $input_money - ${price[$(($select_drink-1))]} ))
      echo $change_pt $changes"円"
      if [ $changes -lt 0 ]; then
         echo "Not enough Money. Next Challenge."
         exit
      fi
      echo -n  $menu_console
      read select_console
      #文字列の戻り値の代わりにファィルへ書き込む。エラー出力として
      echo $select_console >&2 > .tmp.cmd
      break
  else
      echo "Invalid Money!! select 3 types Money"
      echo -n  $money_pt
      continue
  fi
done
}

#無限ループで自動販売機プログラムを呼び出す。
for (( ;; ))
do
   order_drink
   menu=`cat < .tmp.cmd`

   if [ $menu = "p" ]; then
      echo "Success Proceeds Next Drink"
   elif [ $menu = "e" ]; then
      echo "Success Exit of Drink Vending Program"
      exit
   else
      echo "Command not Found."
   fi
done
