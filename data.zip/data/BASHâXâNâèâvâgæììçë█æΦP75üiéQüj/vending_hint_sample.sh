#!/bin/bash


price=(180 170 150 140)
menu_drink=$(cat << EOS
---------------------------------------
| Drink Menu                         |
| 1. トキ・コーラ          180円      |
| 2. イル・コーラ          170円      |
| 3. マンタ・グレープ      150円      |
| 4. MRペッパー            140円      |
---------------------------------------

EOS
)

money_pt="Input Money(100,500,1000)==> "
select_drink_pt="Select Drink==> "
change_pt="Changes == "
menu_console="Menu(終了:e ドリンク継続して買う:p)===>"

echo "$menu_drink"
echo -n  $money_pt
read input_money
echo -n $select_drink_pt
read select_drink
#echo $input_money
#echo $select_drink
changes=$(( $input_money - ${price[$(($select_drink-1))]} ))
echo $change_pt $changes"円"
echo -n  $menu_console
read select_console

if [ $select_console = "p" ]; then
  echo "Success Proceeds"
elif [ $select_console = "e" ]; then
  exit
else
  echo "Command not Found."
fi
